display.setStatusBar(display.HiddenStatusBar)
local physics = require "physics"
physics.start()
grav = physics.setGravity(-8,-10)
local vy = 3
local vx = -3
local scoreText
local scoreNum
local cpuScoreText
local cpuScoreNum
local levelText
local levelNum



-- Variables
local _W = display.contentWidth / 2
local _H = display.contentHeight / 2
local score = 0
local scoreIncrease = 1
local cpuScore = 0
local cpuScoreIncrease = 1
local currentLevel = 1

local speed = 3

--setup graphics
ball = display.newImage("ball.png")
ball.x = 240
ball.y = 160
physics.addBody(ball, {density=1, friction=0, bounce=1})
ball.isFixedRotation = true
ball.isPlatform = true

cpuScoreText = display.newText("Score:", 5, 2, "Verdana", 14)
cpuScoreText:setTextColor(255,255,255,255)

cpuScoreNum = display.newText("0", 54, 2, "Verdana", 14)
cpuScoreNum:setTextColor(255,255,255,255)

scoreText = display.newText("Score:", 420, 2, "Verdana", 14)
scoreText:setTextColor(255,255,255,255)

scoreNum = display.newText("1", 460, 2, "Verdana", 14)
scoreNum:setTextColor(255,255,255,255)

local paddleLeft = display.newImage("paddle.png")
paddleLeft.x = 40
paddleLeft.y = 160
paddleLeft:rotate(90)
physics.addBody(paddleLeft, "static")

local paddleRight = display.newImage("paddle.png")
paddleRight.x = 530
paddleRight.y = 160
paddleRight:rotate(90)
physics.addBody(paddleRight, "static")

local boundaryTop = display.newRect(-10, -1, 570, 1)
physics.addBody(boundaryTop, "static")

local boundaryBottom = display.newRect(-10, 320, 570, 1)
physics.addBody(boundaryBottom, "static")

local boundaryLeft = display.newRect(0, 0, 1, 400)
physics.addBody(boundaryLeft, "static")

local boundaryRight = display.newRect(565, 0, 1, 400)
physics.addBody(boundaryRight, "static")

--paddle movement
function movePaddleLeft(event)
		if event.phase == "moved" then
			transition.to(paddleLeft,{time=4, x=40, y=event.y})
		end
end
Runtime:addEventListener("touch", movePaddleLeft)

function movePaddleRight()
	transition.to(paddleRight,{time=185, x=530, y=ball.y, onComplete=movePaddleRight})
end
movePaddleRight()

--movement

function bounce(event)
	--changed all x for y and ys for xes
	print(event.target.name)
	vx = -3
	if ((ball.y + ball.height * 0.5)< paddleLeft.y) then
		vy = -vy
	elseif((ball.y + ball.height * 0.5) >= paddleLeft.y) then
		vy=vy
	end
end

function bounce2(event)
	--changed all x for y and ys for xes
	print(event.target.name)
	vx = 3
	if ((ball.y + ball.height * 0.5 )< paddleRight.y) then
		vy = -vy
	elseif((ball.y + ball.height * 0.5) >= paddleRight.y) then
		vy=vy*speed
	end

end

function updateBall()
-- exchanged all xes for ys

	ball.y = (ball.y+vy)
	ball.x = (ball.x+vx)

	if ball.y < 0 or ball.y +ball.height > display.contentHeight then
		vy = -vy
	end
	if ball.x < 15 then
--		print("I hit the back wall")
		cpuScore = cpuScore +1
		cpuScoreNum.text=cpuScore * cpuScoreIncrease

		cpuScoreNum:setReferencePoint(display.CenterLeftReferencePoint)
		cpuScoreNum.x = 465
		end

	if ball.x + ball.width > paddleRight.x + paddleRight.width then
		score = score +1
		scoreNum.text=score * scoreIncrease

		scoreNum:setReferencePoint(display.CenterLeftReferencePoint)
		scoreNum.x = 54
		end
end

function gameListeners(event)
	if event == "add" then
		Runtime:addEventListener("enterFrame", updateBall)
		paddleLeft:addEventListener("collision", bounce)
		paddleRight:addEventListener("collision", bounce2)
		PaddleLeft:addEventListener("touch", dragPaddle)
	elseif event == "remove" then
		Runtime:removeEventListener("enterFrame", updateBall)
		paddleLeft:removeEventListener("collision", bounce)
		paddleRight:removeEventListener("collision", bounce2)
		paddleLeft:removeEventListener("touch", dragPaddle)
	end

end	



function changeGravity()
	physics.setGravity(0,0)
end

paddleLeft:addEventListener("collision", changeGravity)


